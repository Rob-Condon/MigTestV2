<?php
/*
Plugin Name: Z Auto Content
Plugin URI: http://televisodes.com
Description: Untuk mengenerate content ketika content kosong.
Version: 1.0
Author: Dudut Lesmono
Author URI: http://televisodes.com
*/

add_filter( 'the_content', 'auto_content' ); 
function auto_content( $content ) {
	global $post;

	if($content==""){
		//post title : Shark Tank Season 6 Episode 29
		/*
		output pada post_content
		You can watch Shark Tank Season 6 Episode 29 online. Shark Tank season 6 episode 29.
		Shark Tank episodes can be found on our website including the new Shark Tank episodes.
		Shark Tank season 6 episode 29 online streaming. Watch Shark Tank Online. 
		You’ll be able to watch Shark Tank online with us anytime without any restrictions or limitations. 
		Just remember Shark Tank can be watched from anywhere in the world. 
		The latest season 6 episode 29 is the next chapter in this season and it’s jam packed with exciting scenes. 
		*/
		$title=$post->post_title;
		
		$pos_1=strpos($title,"Season");
		$pos_2=strpos($title,"Episode");
		$film_name=substr($title,0,$pos_1);
		$season_episode=substr($title,$pos_1);

		//echo "film_name: ".$film_name."<br>";

		$hasil="You can watch ".$title." online. ".$film_name." ".strtolower($season_episode).".";
		$hasil.=$film_name." episodes can be found on our website including the new ".$film_name." episodes.";
		$hasil.=$film_name." ".strtolower($season_episode)." online streaming. Watch ".$film_name." Online.";
		$hasil.="You’ll be able to watch ".$film_name." online with us anytime without any restrictions or limitations. ";
		$hasil.="Just remember ".$film_name." can be watched from anywhere in the world.";
		$hasil.="The latest ".strtolower($season_episode)." is the next chapter in this season and it’s jam packed with exciting scenes. ";
		
		//$content=$content."ini auto ".$post->ID." ".$post->post_title;
		$content=$content.$hasil;
		
	}
	return $content;
} 


?>